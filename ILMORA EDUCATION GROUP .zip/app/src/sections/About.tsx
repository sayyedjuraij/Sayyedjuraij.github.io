import { useEffect, useRef, useState } from 'react';
import { Award, Globe, Heart, Target, Lightbulb, Shield } from 'lucide-react';

const About = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const coreValues = [
    { icon: Lightbulb, title: 'Knowledge-driven excellence' },
    { icon: Shield, title: 'Integrity and transparency' },
    { icon: Heart, title: 'Human-centered growth' },
    { icon: Award, title: 'Ethical professional practices' },
    { icon: Target, title: 'Long-term educational impact' },
  ];

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative py-20 lg:py-32 bg-eduvista-light-bg overflow-hidden"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-20 right-20 w-64 h-64 bg-eduvista-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-20 w-48 h-48 bg-eduvista-secondary/5 rounded-full blur-2xl" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* About Us Content */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center mb-20">
          {/* Image */}
          <div
            className={`relative transition-all duration-1000 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-12'
            }`}
          >
            {/* Decorative Frame */}
            <div className="absolute -top-4 -left-4 w-full h-full border-4 border-eduvista-primary/30 rounded-3xl" />
            <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-eduvista-primary/20 rounded-2xl" />
            
            {/* Main Image */}
            <div className="relative rounded-3xl overflow-hidden shadow-2xl">
              <img
                src="/about-student.jpg"
                alt="Student reading"
                className="w-full h-auto object-cover"
              />
            </div>
          </div>

          {/* Content */}
          <div>
            {/* Label */}
            <div
              className={`inline-block px-4 py-1.5 rounded-full bg-eduvista-primary/20 mb-4 transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
              }`}
            >
              <span className="text-eduvista-secondary text-sm font-semibold uppercase tracking-wider">
                About Us
              </span>
            </div>

            {/* Headline */}
            <h2
              className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-eduvista-secondary leading-tight mb-6 transition-all duration-700 delay-100 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              Knowledge-Driven
              <span className="text-eduvista-primary"> Organization</span>
            </h2>

            {/* Body Text */}
            <div
              className={`space-y-4 mb-8 transition-all duration-700 delay-200 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              <p className="text-eduvista-text-gray leading-relaxed">
                ILMORA Education Group is a knowledge-driven organization dedicated to education, 
                psychological wellbeing, and professional skill development. We focus on guiding 
                individuals toward academic growth, career clarity, and personal development through 
                structured learning systems and ethical practices.
              </p>
              <p className="text-eduvista-text-gray leading-relaxed">
                With a vision to build future-ready institutions, ILMORA Education Group integrates 
                education, healthcare learning, psychology, and human development under one unified brand. 
                Our approach is professional, research-oriented, and learner-focused, ensuring quality 
                guidance and long-term impact.
              </p>
            </div>
          </div>
        </div>

        {/* Vision & Mission */}
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {/* Vision */}
          <div
            className={`bg-white rounded-3xl p-8 shadow-lg transition-all duration-700 delay-300 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            <div className="p-4 rounded-2xl bg-eduvista-primary/20 w-fit mb-6">
              <Globe className="w-8 h-8 text-eduvista-secondary" />
            </div>
            <h3 className="text-2xl font-bold text-eduvista-secondary mb-4">Our Vision</h3>
            <p className="text-eduvista-text-gray leading-relaxed">
              To become a trusted international education group advancing minds, skills, and 
              wellbeing through knowledge-based institutions.
            </p>
          </div>

          {/* Mission */}
          <div
            className={`bg-white rounded-3xl p-8 shadow-lg transition-all duration-700 delay-400 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            <div className="p-4 rounded-2xl bg-eduvista-primary/20 w-fit mb-6">
              <Target className="w-8 h-8 text-eduvista-secondary" />
            </div>
            <h3 className="text-2xl font-bold text-eduvista-secondary mb-4">Our Mission</h3>
            <p className="text-eduvista-text-gray leading-relaxed">
              To deliver high-quality educational services, healthcare-oriented learning, and 
              psychological guidance through professional standards, ethical values, and 
              student-centered systems.
            </p>
          </div>
        </div>

        {/* Core Values */}
        <div
          className={`transition-all duration-700 delay-500 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <h3 className="text-2xl font-bold text-eduvista-secondary text-center mb-8">Core Values</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {coreValues.map((value, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl p-6 text-center shadow-md hover:shadow-lg hover:-translate-y-1 transition-all duration-300 group"
              >
                <div className="p-3 rounded-xl bg-eduvista-primary/10 w-fit mx-auto mb-4 group-hover:bg-eduvista-primary transition-colors duration-300">
                  <value.icon className="w-6 h-6 text-eduvista-secondary" />
                </div>
                <p className="text-sm font-medium text-eduvista-text-dark">{value.title}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
