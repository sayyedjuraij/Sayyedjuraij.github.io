import { useEffect, useRef, useState } from 'react';
import { Phone, Clock, Send, Globe } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

const Contact = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [showDialog, setShowDialog] = useState(false);
  const [dialogMessage, setDialogMessage] = useState('');
  const sectionRef = useRef<HTMLElement>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    service: '',
    message: '',
  });

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setDialogMessage('Thank you for your inquiry! Our team will contact you within 24 hours.');
    setShowDialog(true);
    setFormData({ name: '', email: '', phone: '', service: '', message: '' });
  };

  const services = [
    'Education Counseling',
    'Career Planning',
    'Psychology Support',
    'Healthcare Education',
    'Institutional Training',
    'Educational Consulting',
    'Other',
  ];

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="relative py-20 lg:py-32 bg-white overflow-hidden"
    >
      {/* Background Elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-eduvista-primary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-eduvista-secondary/5 rounded-full blur-3xl" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
          {/* Content */}
          <div>
            {/* Label */}
            <div
              className={`inline-block px-4 py-1.5 rounded-full bg-eduvista-primary/20 mb-4 transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
              }`}
            >
              <span className="text-eduvista-secondary text-sm font-semibold uppercase tracking-wider">
                Contact Us
              </span>
            </div>

            {/* Headline */}
            <h2
              className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-eduvista-secondary leading-tight mb-4 transition-all duration-700 delay-100 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              Get in Touch With
              <span className="text-eduvista-primary"> ILMORA</span>
            </h2>

            <p
              className={`text-eduvista-text-gray text-lg mb-8 transition-all duration-700 delay-200 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              Connect with us for professional educational guidance and support. 
              We're here to help you advance your academic and professional journey.
            </p>

            {/* Contact Info */}
            <div className="space-y-6">
              <div
                className={`flex items-center gap-4 transition-all duration-500 ${
                  isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-4'
                }`}
                style={{ transitionDelay: '300ms' }}
              >
                <div className="p-3 rounded-xl bg-eduvista-primary/10">
                  <Phone className="w-5 h-5 text-eduvista-secondary" />
                </div>
                <div>
                  <div className="text-sm text-eduvista-text-gray">UAE</div>
                  <div className="font-medium text-eduvista-secondary">+971 52 968 2123</div>
                </div>
              </div>

              <div
                className={`flex items-center gap-4 transition-all duration-500 ${
                  isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-4'
                }`}
                style={{ transitionDelay: '400ms' }}
              >
                <div className="p-3 rounded-xl bg-eduvista-primary/10">
                  <Phone className="w-5 h-5 text-eduvista-secondary" />
                </div>
                <div>
                  <div className="text-sm text-eduvista-text-gray">India</div>
                  <div className="font-medium text-eduvista-secondary">+91 97449 80875</div>
                </div>
              </div>

              <div
                className={`flex items-center gap-4 transition-all duration-500 ${
                  isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-4'
                }`}
                style={{ transitionDelay: '500ms' }}
              >
                <div className="p-3 rounded-xl bg-eduvista-primary/10">
                  <Globe className="w-5 h-5 text-eduvista-secondary" />
                </div>
                <div>
                  <div className="text-sm text-eduvista-text-gray">Operating Regions</div>
                  <div className="font-medium text-eduvista-secondary">UAE & India</div>
                </div>
              </div>

              <div
                className={`flex items-center gap-4 transition-all duration-500 ${
                  isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-4'
                }`}
                style={{ transitionDelay: '600ms' }}
              >
                <div className="p-3 rounded-xl bg-eduvista-primary/10">
                  <Clock className="w-5 h-5 text-eduvista-secondary" />
                </div>
                <div>
                  <div className="text-sm text-eduvista-text-gray">Business Hours</div>
                  <div className="font-medium text-eduvista-secondary">Mon - Sat: 9AM - 6PM</div>
                </div>
              </div>
            </div>

            {/* Legal Notice */}
            <div
              className={`mt-8 p-4 bg-eduvista-light-bg rounded-xl transition-all duration-700 delay-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              <p className="text-xs text-eduvista-text-gray leading-relaxed">
                <span className="font-semibold">Legal Status:</span> ILMORA Education Group operates 
                as a professional education and advisory brand. Legal registrations are under process 
                and will be updated as per regional regulatory requirements.
              </p>
            </div>
          </div>

          {/* Form */}
          <div
            className={`transition-all duration-700 delay-400 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            <form onSubmit={handleSubmit} className="bg-eduvista-light-bg rounded-3xl p-8 shadow-lg">
              <div className="grid sm:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-sm font-medium text-eduvista-secondary mb-2">
                    Full Name
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-eduvista-primary focus:ring-2 focus:ring-eduvista-primary/20 outline-none transition-all duration-300"
                    placeholder="Your name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-eduvista-secondary mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-eduvista-primary focus:ring-2 focus:ring-eduvista-primary/20 outline-none transition-all duration-300"
                    placeholder="your@email.com"
                  />
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-sm font-medium text-eduvista-secondary mb-2">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-eduvista-primary focus:ring-2 focus:ring-eduvista-primary/20 outline-none transition-all duration-300"
                    placeholder="+971 or +91"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-eduvista-secondary mb-2">
                    Service Interested In
                  </label>
                  <select
                    required
                    value={formData.service}
                    onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-eduvista-primary focus:ring-2 focus:ring-eduvista-primary/20 outline-none transition-all duration-300 bg-white"
                  >
                    <option value="">Select a service</option>
                    {services.map((service, index) => (
                      <option key={index} value={service}>
                        {service}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-eduvista-secondary mb-2">
                  Message
                </label>
                <textarea
                  rows={4}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-eduvista-primary focus:ring-2 focus:ring-eduvista-primary/20 outline-none transition-all duration-300 resize-none"
                  placeholder="Tell us about your requirements..."
                />
              </div>

              <button
                type="submit"
                className="w-full group flex items-center justify-center gap-2 px-8 py-4 bg-eduvista-secondary text-white rounded-full font-semibold transition-all duration-300 hover:bg-eduvista-primary hover:text-eduvista-secondary"
              >
                Send Inquiry
                <Send className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-1" />
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-eduvista-secondary">Thank You!</DialogTitle>
            <DialogDescription className="text-eduvista-text-gray">
              {dialogMessage}
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-center mt-4">
            <button
              onClick={() => setShowDialog(false)}
              className="px-6 py-2 bg-eduvista-primary text-eduvista-secondary rounded-full font-semibold hover:bg-eduvista-secondary hover:text-white transition-colors duration-300"
            >
              Close
            </button>
          </div>
        </DialogContent>
      </Dialog>
    </section>
  );
};

export default Contact;
