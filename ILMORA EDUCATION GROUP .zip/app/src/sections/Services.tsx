import { useEffect, useRef, useState } from 'react';
import { Compass, Briefcase, Brain, Stethoscope, Building2, MessageSquare, ArrowRight, CheckCircle2 } from 'lucide-react';

interface ServiceCardProps {
  icon: React.ElementType;
  title: string;
  description: string;
  delay: number;
  isVisible: boolean;
}

const ServiceCard = ({ icon: Icon, title, description, delay, isVisible }: ServiceCardProps) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className={`group relative bg-white rounded-3xl p-8 shadow-lg transition-all duration-700 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
      }`}
      style={{ transitionDelay: `${delay}ms` }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Hover Border Effect */}
      <div
        className={`absolute inset-0 rounded-3xl border-2 border-eduvista-primary transition-all duration-500 ${
          isHovered ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
        }`}
      />

      {/* Icon */}
      <div
        className={`relative w-16 h-16 rounded-2xl flex items-center justify-center mb-6 transition-all duration-500 ${
          isHovered ? 'bg-eduvista-secondary rotate-[360deg]' : 'bg-eduvista-primary/20'
        }`}
      >
        <Icon
          className={`w-8 h-8 transition-colors duration-500 ${
            isHovered ? 'text-eduvista-primary' : 'text-eduvista-secondary'
          }`}
        />
      </div>

      {/* Content */}
      <h3 className="text-xl font-bold text-eduvista-secondary mb-3">{title}</h3>
      <p className="text-eduvista-text-gray leading-relaxed">{description}</p>

      {/* Arrow */}
      <div
        className={`absolute bottom-8 right-8 transition-all duration-300 ${
          isHovered ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-2'
        }`}
      >
        <ArrowRight className="w-5 h-5 text-eduvista-primary" />
      </div>
    </div>
  );
};

const Services = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const services = [
    {
      icon: Compass,
      title: 'Education Counseling',
      description: 'Comprehensive academic guidance to help students navigate their educational journey and make informed decisions.',
    },
    {
      icon: Briefcase,
      title: 'Career Planning',
      description: 'Strategic career development programs focusing on skill building, goal setting, and professional growth pathways.',
    },
    {
      icon: Brain,
      title: 'Psychology Support',
      description: 'Mental wellbeing services and psychological guidance to support personal development and emotional health.',
    },
    {
      icon: Stethoscope,
      title: 'Healthcare Education',
      description: 'Specialized guidance for paramedical and healthcare education, connecting students with quality institutions.',
    },
    {
      icon: Building2,
      title: 'Institutional Training',
      description: 'Professional learning programs and training solutions designed for educational institutions and organizations.',
    },
    {
      icon: MessageSquare,
      title: 'Educational Consulting',
      description: 'Expert advisory services for educational planning, curriculum development, and institutional growth strategies.',
    },
  ];

  const whyChooseUs = [
    'Professional and ethical approach',
    'Experienced academic and healthcare guidance',
    'Focus on long-term student success',
    'Integrated education and wellbeing model',
    'International outlook with local understanding',
  ];

  return (
    <section
      id="services"
      ref={sectionRef}
      className="relative py-20 lg:py-32 bg-white overflow-hidden"
    >
      {/* Background Elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-eduvista-primary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-eduvista-secondary/5 rounded-full blur-3xl" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div
            className={`inline-block px-4 py-1.5 rounded-full bg-eduvista-primary/20 mb-4 transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            <span className="text-eduvista-secondary text-sm font-semibold uppercase tracking-wider">
              Our Services
            </span>
          </div>
          <h2
            className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-eduvista-secondary leading-tight mb-4 transition-all duration-700 delay-100 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
          >
            Comprehensive
            <span className="text-eduvista-primary"> Solutions</span>
          </h2>
          <p
            className={`text-eduvista-text-gray text-lg transition-all duration-700 delay-200 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
          >
            Integrated education, healthcare learning, psychology, and human development services
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {services.map((service, index) => (
            <ServiceCard
              key={index}
              {...service}
              delay={300 + index * 100}
              isVisible={isVisible}
            />
          ))}
        </div>

        {/* Why Choose Us */}
        <div
          className={`bg-eduvista-secondary rounded-3xl p-8 lg:p-12 transition-all duration-700 delay-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl lg:text-3xl font-bold text-white mb-4">
                Why Choose <span className="text-eduvista-primary">ILMORA</span>
              </h3>
              <p className="text-white/70 leading-relaxed">
                We combine professional expertise with ethical practices to deliver 
                long-term educational impact and human-centered growth.
              </p>
            </div>
            <div className="space-y-4">
              {whyChooseUs.map((item, index) => (
                <div
                  key={index}
                  className="flex items-center gap-3 text-white/80"
                >
                  <CheckCircle2 className="w-5 h-5 text-eduvista-primary flex-shrink-0" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;
