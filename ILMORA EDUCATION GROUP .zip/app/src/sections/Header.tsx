import { useState, useEffect } from 'react';
import { Menu, X, GraduationCap } from 'lucide-react';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Services', href: '#services' },
    { name: 'Programs', href: '#programs' },
    { name: 'Contact', href: '#contact' },
  ];

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled
          ? 'bg-white/90 backdrop-blur-xl shadow-lg py-3'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a
            href="#home"
            onClick={(e) => {
              e.preventDefault();
              scrollToSection('#home');
            }}
            className="flex items-center gap-2 group"
          >
            <div
              className={`p-2 rounded-xl transition-all duration-300 ${
                isScrolled
                  ? 'bg-eduvista-primary'
                  : 'bg-white/20 backdrop-blur-sm'
              }`}
            >
              <GraduationCap
                className={`w-6 h-6 transition-colors duration-300 ${
                  isScrolled ? 'text-eduvista-secondary' : 'text-white'
                }`}
              />
            </div>
            <span
              className={`text-lg font-bold font-['Playfair_Display'] transition-colors duration-300 ${
                isScrolled ? 'text-eduvista-secondary' : 'text-white'
              }`}
            >
              ILMORA
            </span>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection(link.href);
                }}
                className={`relative text-sm font-medium transition-all duration-300 group ${
                  isScrolled
                    ? 'text-eduvista-text-dark hover:text-eduvista-primary'
                    : 'text-white/90 hover:text-white'
                }`}
              >
                {link.name}
                <span
                  className={`absolute -bottom-1 left-1/2 w-0 h-0.5 transition-all duration-300 group-hover:w-full group-hover:left-0 ${
                    isScrolled ? 'bg-eduvista-primary' : 'bg-white'
                  }`}
                />
              </a>
            ))}
          </nav>

          {/* CTA Button */}
          <div className="hidden md:block">
            <button
              onClick={() => scrollToSection('#contact')}
              className={`px-6 py-2.5 rounded-full font-semibold text-sm transition-all duration-300 ${
                isScrolled
                  ? 'bg-eduvista-primary text-eduvista-secondary hover:bg-eduvista-secondary hover:text-eduvista-primary'
                  : 'bg-white text-eduvista-secondary hover:bg-eduvista-primary hover:text-eduvista-secondary'
              }`}
            >
              Get Started
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className={`md:hidden p-2 rounded-lg transition-colors duration-300 ${
              isScrolled
                ? 'text-eduvista-secondary hover:bg-eduvista-light-bg'
                : 'text-white hover:bg-white/10'
            }`}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        <div
          className={`md:hidden overflow-hidden transition-all duration-500 ${
            isMobileMenuOpen ? 'max-h-96 mt-4' : 'max-h-0'
          }`}
        >
          <nav className="flex flex-col gap-2 py-4">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection(link.href);
                }}
                className={`px-4 py-3 rounded-lg text-sm font-medium transition-all duration-300 ${
                  isScrolled
                    ? 'text-eduvista-text-dark hover:bg-eduvista-light-bg hover:text-eduvista-primary'
                    : 'text-white hover:bg-white/10'
                }`}
              >
                {link.name}
              </a>
            ))}
            <button
              onClick={() => scrollToSection('#contact')}
              className="mt-2 px-6 py-3 rounded-full font-semibold text-sm bg-eduvista-primary text-eduvista-secondary"
            >
              Get Started
            </button>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
