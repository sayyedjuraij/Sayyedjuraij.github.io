import { useEffect, useRef, useState } from 'react';
import { Brain, Heart, ArrowRight, HandHeart, Sparkles, Target, Lightbulb } from 'lucide-react';

const PsychologyWellbeing = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const approaches = [
    {
      icon: Brain,
      title: 'Psychological Assessment',
      description: 'Scientific evaluation of personality traits, aptitudes, and cognitive abilities to understand individual potential.',
    },
    {
      icon: Heart,
      title: 'Mental Wellbeing Support',
      description: 'Professional counseling and emotional support to foster resilience, confidence, and personal growth.',
    },
  ];

  const benefits = [
    { icon: Sparkles, text: 'Enhanced self-awareness' },
    { icon: Target, text: 'Clearer life direction' },
    { icon: Lightbulb, text: 'Better decision-making' },
    { icon: HandHeart, text: 'Emotional resilience' },
  ];

  return (
    <section
      ref={sectionRef}
      className="relative py-20 lg:py-32 bg-white overflow-hidden"
    >
      {/* Background Elements */}
      <div className="absolute top-0 left-1/2 w-96 h-96 bg-eduvista-primary/5 rounded-full blur-3xl -translate-x-1/2" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Image */}
          <div
            className={`relative transition-all duration-1000 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-12'
            }`}
          >
            {/* Decorative Elements */}
            <div className="absolute -top-4 -left-4 w-full h-full border-4 border-eduvista-primary/20 rounded-3xl" />
            <div className="absolute top-1/2 -right-8 w-16 h-16 bg-eduvista-primary/30 rounded-full animate-float" />
            <div className="absolute -bottom-6 left-1/4 w-8 h-8 bg-eduvista-secondary/20 rounded-full animate-float-slow" />
            
            {/* Main Image */}
            <div className="relative rounded-3xl overflow-hidden shadow-2xl">
              <img
                src="/career-guidance.jpg"
                alt="Counseling session"
                className="w-full h-auto object-cover"
              />
            </div>

            {/* Floating Card */}
            <div className="absolute -bottom-6 -right-6 bg-eduvista-secondary rounded-2xl p-5 shadow-xl animate-float" style={{ animationDelay: '0.5s' }}>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-eduvista-primary/20 flex items-center justify-center">
                  <Heart className="w-6 h-6 text-eduvista-primary" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-white">Human-Centered</div>
                  <div className="text-xs text-white/70">Growth Approach</div>
                </div>
              </div>
            </div>
          </div>

          {/* Content */}
          <div>
            {/* Label */}
            <div
              className={`inline-block px-4 py-1.5 rounded-full bg-eduvista-primary/20 mb-4 transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
              }`}
            >
              <span className="text-eduvista-secondary text-sm font-semibold uppercase tracking-wider">
                Psychology & Wellbeing
              </span>
            </div>

            {/* Headline */}
            <h2
              className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-eduvista-secondary leading-tight mb-4 transition-all duration-700 delay-100 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              Supporting Your
              <span className="text-eduvista-primary"> Mental</span>
              <br />& Emotional Wellbeing
            </h2>

            {/* Subheadline */}
            <p
              className={`text-lg text-eduvista-text-gray mb-6 transition-all duration-700 delay-200 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              Professional psychological guidance for personal growth and development
            </p>

            {/* Body */}
            <p
              className={`text-eduvista-text-gray leading-relaxed mb-8 transition-all duration-700 delay-300 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              At ILMORA, we believe that mental wellbeing is fundamental to achieving educational 
              and professional success. Our psychology services provide a safe, confidential space 
              for individuals to explore their thoughts, feelings, and behaviors while developing 
              strategies for personal growth.
            </p>

            {/* Approach Cards */}
            <div className="grid sm:grid-cols-2 gap-4 mb-8">
              {approaches.map((approach, index) => (
                <div
                  key={index}
                  className={`p-5 rounded-2xl bg-eduvista-light-bg hover:bg-eduvista-primary/10 transition-all duration-500 group cursor-pointer ${
                    isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
                  }`}
                  style={{ transitionDelay: `${400 + index * 100}ms` }}
                >
                  <div className="p-3 rounded-xl bg-white shadow-sm w-fit mb-4 group-hover:bg-eduvista-primary transition-colors duration-300">
                    <approach.icon className="w-6 h-6 text-eduvista-secondary group-hover:text-eduvista-secondary" />
                  </div>
                  <h4 className="font-semibold text-eduvista-secondary mb-2">{approach.title}</h4>
                  <p className="text-sm text-eduvista-text-gray">{approach.description}</p>
                </div>
              ))}
            </div>

            {/* Benefits */}
            <div
              className={`mb-8 transition-all duration-700 delay-600 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              <h4 className="font-semibold text-eduvista-secondary mb-4">Key Benefits</h4>
              <div className="flex flex-wrap gap-3">
                {benefits.map((benefit, index) => (
                  <div
                    key={index}
                    className="flex items-center gap-2 px-4 py-2 rounded-full bg-eduvista-primary/10"
                  >
                    <benefit.icon className="w-4 h-4 text-eduvista-primary" />
                    <span className="text-sm text-eduvista-text-dark">{benefit.text}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* CTA */}
            <button
              className={`group inline-flex items-center gap-2 px-8 py-4 bg-eduvista-primary text-eduvista-secondary rounded-full font-semibold transition-all duration-700 delay-700 hover:bg-eduvista-secondary hover:text-eduvista-primary ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              Book a Consultation
              <ArrowRight className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-1" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PsychologyWellbeing;
