import Header from './sections/Header';
import Hero from './sections/Hero';
import About from './sections/About';
import Services from './sections/Services';
import Programs from './sections/WorkingProfessionals';
import PsychologyWellbeing from './sections/CareerGuidance';
import Partnerships from './sections/AbroadAdmissions';
import Testimonials from './sections/Testimonials';
import Contact from './sections/Contact';
import Footer from './sections/Footer';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <Hero />
        <About />
        <Services />
        <Programs />
        <PsychologyWellbeing />
        <Partnerships />
        <Testimonials />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
