import { useEffect, useRef, useState } from 'react';
import { Check, ArrowRight, GraduationCap, Brain, Stethoscope, Users, BookOpen, Award, Heart } from 'lucide-react';

const Programs = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const programAreas = [
    {
      icon: GraduationCap,
      title: 'Education & Academic Programs',
      description: 'UG, PG, and diploma programs with flexible learning options',
    },
    {
      icon: Brain,
      title: 'Psychology & Counselling',
      description: 'Mental health support and psychological guidance services',
    },
    {
      icon: Stethoscope,
      title: 'Healthcare & Paramedical',
      description: 'Nursing, pharmacy, and allied health science programs',
    },
    {
      icon: BookOpen,
      title: 'Professional Development',
      description: 'Skill-based training and career advancement courses',
    },
  ];

  const features = [
    { icon: Users, text: 'Personalized guidance for every student' },
    { icon: Award, text: 'Recognized certifications and degrees' },
    { icon: Heart, text: 'Holistic wellbeing approach' },
    { icon: BookOpen, text: 'Research-oriented learning systems' },
  ];

  return (
    <section
      id="programs"
      ref={sectionRef}
      className="relative py-20 lg:py-32 bg-eduvista-light-bg overflow-hidden"
    >
      {/* Background Elements */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-eduvista-primary/10 rounded-full blur-3xl -translate-y-1/2" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Content */}
          <div className="order-2 lg:order-1">
            {/* Label */}
            <div
              className={`inline-block px-4 py-1.5 rounded-full bg-eduvista-primary/20 mb-4 transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
              }`}
            >
              <span className="text-eduvista-secondary text-sm font-semibold uppercase tracking-wider">
                Our Programs
              </span>
            </div>

            {/* Headline */}
            <h2
              className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-eduvista-secondary leading-tight mb-4 transition-all duration-700 delay-100 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              Building
              <span className="text-eduvista-primary"> Future-Ready</span>
              <br />Institutions
            </h2>

            {/* Subheadline */}
            <p
              className={`text-lg text-eduvista-text-gray mb-6 transition-all duration-700 delay-200 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              Integrating education, healthcare learning, and human development
            </p>

            {/* Body */}
            <p
              className={`text-eduvista-text-gray leading-relaxed mb-8 transition-all duration-700 delay-300 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              ILMORA Education Group connects students and professionals with quality institutions 
              across UAE and India. Our programs are designed to provide structured learning systems 
              that emphasize ethical practices, professional standards, and long-term success.
            </p>

            {/* Program Areas */}
            <div className="grid sm:grid-cols-2 gap-4 mb-8">
              {programAreas.map((program, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-xl bg-white shadow-sm hover:shadow-md transition-all duration-500 group cursor-pointer ${
                    isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
                  }`}
                  style={{ transitionDelay: `${400 + index * 100}ms` }}
                >
                  <div className="p-2 rounded-lg bg-eduvista-primary/10 w-fit mb-3 group-hover:bg-eduvista-primary transition-colors duration-300">
                    <program.icon className="w-5 h-5 text-eduvista-secondary" />
                  </div>
                  <h4 className="font-semibold text-eduvista-secondary text-sm mb-1">{program.title}</h4>
                  <p className="text-xs text-eduvista-text-gray">{program.description}</p>
                </div>
              ))}
            </div>

            {/* Features */}
            <div className="flex flex-wrap gap-3 mb-8">
              {features.map((feature, index) => (
                <div
                  key={index}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full bg-white shadow-sm transition-all duration-500 ${
                    isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-4'
                  }`}
                  style={{ transitionDelay: `${800 + index * 50}ms` }}
                >
                  <feature.icon className="w-4 h-4 text-eduvista-primary" />
                  <span className="text-sm text-eduvista-text-dark">{feature.text}</span>
                </div>
              ))}
            </div>

            {/* CTA */}
            <button
              className={`group inline-flex items-center gap-2 px-8 py-4 bg-eduvista-secondary text-white rounded-full font-semibold transition-all duration-700 delay-700 hover:bg-eduvista-primary hover:text-eduvista-secondary ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              Explore Programs
              <ArrowRight className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-1" />
            </button>
          </div>

          {/* Image */}
          <div
            className={`order-1 lg:order-2 relative transition-all duration-1000 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-12'
            }`}
          >
            {/* Decorative Elements */}
            <div className="absolute -top-6 -right-6 w-32 h-32 bg-eduvista-primary/20 rounded-2xl animate-float" />
            <div className="absolute -bottom-4 -left-4 w-24 h-24 border-4 border-eduvista-primary/30 rounded-full animate-float-slow" />
            
            {/* Main Image */}
            <div className="relative rounded-3xl overflow-hidden shadow-2xl">
              <img
                src="/working-professional.jpg"
                alt="Professional learning"
                className="w-full h-auto object-cover"
              />
              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-eduvista-secondary/20 to-transparent" />
            </div>

            {/* Floating Badge */}
            <div className="absolute -bottom-4 -right-4 bg-white rounded-2xl p-4 shadow-xl animate-float" style={{ animationDelay: '1s' }}>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-eduvista-primary/20 flex items-center justify-center">
                  <Check className="w-6 h-6 text-eduvista-secondary" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-eduvista-secondary">Professional</div>
                  <div className="text-xs text-eduvista-text-gray">& Ethical Approach</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Programs;
