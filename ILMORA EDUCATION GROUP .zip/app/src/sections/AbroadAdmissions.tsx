import { useEffect, useRef, useState } from 'react';
import { MapPin, ArrowRight, Building2, FileText, ScrollText, Plane, BadgeDollarSign, Users, GraduationCap, Handshake } from 'lucide-react';

const Partnerships = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const regions = [
    {
      icon: MapPin,
      region: 'United Arab Emirates',
      focus: 'Higher education & professional training',
      highlight: 'World-class institutions',
    },
    {
      icon: MapPin,
      region: 'India',
      focus: 'UG, PG & healthcare programs',
      highlight: 'Diverse opportunities',
    },
  ];

  const partnershipTypes = [
    { icon: GraduationCap, title: 'Universities & Colleges', desc: 'Academic institutions' },
    { icon: Building2, title: 'Training Centers', desc: 'Professional development' },
    { icon: Users, title: 'Counseling Centers', desc: 'Mental wellbeing support' },
    { icon: Handshake, title: 'Healthcare Institutes', desc: 'Medical & paramedical' },
  ];

  const services = [
    { icon: FileText, text: 'Institution shortlisting' },
    { icon: ScrollText, text: 'Application assistance' },
    { icon: Plane, text: 'Admission guidance' },
    { icon: BadgeDollarSign, text: 'Scholarship information' },
    { icon: Users, text: 'Career counseling' },
    { icon: Building2, text: 'Institutional consulting' },
  ];

  return (
    <section
      ref={sectionRef}
      className="relative py-20 lg:py-32 bg-eduvista-secondary overflow-hidden"
    >
      {/* Background Elements */}
      <div className="absolute inset-0">
        {/* Pattern Overlay */}
        <div 
          className="absolute inset-0 opacity-5"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M20,50 Q30,30 50,30 Q70,30 80,50 Q70,70 50,70 Q30,70 20,50' fill='none' stroke='white' stroke-width='0.5'/%3E%3C/svg%3E")`,
            backgroundSize: '200px 200px',
          }}
        />
        <div className="absolute top-20 left-20 w-96 h-96 bg-eduvista-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-20 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div
            className={`inline-block px-4 py-1.5 rounded-full bg-white/10 mb-4 transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            <span className="text-eduvista-primary text-sm font-semibold uppercase tracking-wider">
              Our Network
            </span>
          </div>
          <h2
            className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-white leading-tight mb-4 transition-all duration-700 delay-100 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
          >
            Strategic
            <span className="text-eduvista-primary"> Partnerships</span>
          </h2>
          <p
            className={`text-white/70 text-lg transition-all duration-700 delay-200 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
          >
            Connecting students with quality institutions across UAE and India
          </p>
          <p
            className={`text-white/60 mt-4 transition-all duration-700 delay-300 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
          >
            ILMORA Education Group partners with leading educational institutions, training centers, 
            and healthcare organizations to provide comprehensive learning opportunities and 
            professional development pathways.
          </p>
        </div>

        {/* Regions */}
        <div className="grid md:grid-cols-2 gap-6 mb-16">
          {regions.map((region, index) => (
            <div
              key={index}
              className={`group bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 hover:bg-white/10 hover:border-eduvista-primary/50 transition-all duration-500 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
              }`}
              style={{ transitionDelay: `${400 + index * 100}ms` }}
            >
              <div className="p-4 rounded-xl bg-eduvista-primary/20 w-fit mb-6 group-hover:bg-eduvista-primary transition-colors duration-300">
                <region.icon className="w-8 h-8 text-eduvista-primary" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">{region.region}</h3>
              <p className="text-white/60 mb-4">{region.focus}</p>
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-eduvista-primary" />
                <span className="text-sm text-eduvista-primary">{region.highlight}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Partnership Types */}
        <div
          className={`grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16 transition-all duration-700 delay-600 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {partnershipTypes.map((type, index) => (
            <div
              key={index}
              className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 text-center hover:bg-white/10 transition-all duration-300"
            >
              <div className="p-3 rounded-xl bg-eduvista-primary/20 w-fit mx-auto mb-4">
                <type.icon className="w-6 h-6 text-eduvista-primary" />
              </div>
              <h4 className="font-semibold text-white mb-1">{type.title}</h4>
              <p className="text-sm text-white/50">{type.desc}</p>
            </div>
          ))}
        </div>

        {/* Services Included */}
        <div
          className={`bg-white/5 backdrop-blur-sm rounded-3xl p-8 lg:p-12 border border-white/10 transition-all duration-700 delay-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <h3 className="text-xl font-bold text-white mb-8 text-center">Services We Provide</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service, index) => (
              <div
                key={index}
                className="flex items-center gap-4 group"
              >
                <div className="p-3 rounded-xl bg-eduvista-primary/20 group-hover:bg-eduvista-primary transition-colors duration-300">
                  <service.icon className="w-5 h-5 text-eduvista-primary group-hover:text-eduvista-secondary" />
                </div>
                <span className="text-white/80 group-hover:text-white transition-colors duration-300">
                  {service.text}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div
          className={`text-center mt-12 transition-all duration-700 delay-800 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
        >
          <button className="group inline-flex items-center gap-2 px-8 py-4 bg-eduvista-primary text-eduvista-secondary rounded-full font-semibold transition-all duration-300 hover:bg-white hover:scale-105 hover:shadow-[0_0_30px_rgba(249,216,6,0.5)]">
            Become a Partner
            <ArrowRight className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-1" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default Partnerships;
