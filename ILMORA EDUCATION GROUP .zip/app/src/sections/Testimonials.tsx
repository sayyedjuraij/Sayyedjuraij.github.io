import { useEffect, useRef, useState } from 'react';
import { Quote, Star, ChevronLeft, ChevronRight } from 'lucide-react';

const Testimonials = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  // Auto-rotate testimonials
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % testimonials.length);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const testimonials = [
    {
      image: '/testimonial-1.jpg',
      name: 'Aisha Al-Rashid',
      program: 'Higher Education',
      detail: 'MBA Program, Dubai',
      rating: 5,
      quote: 'ILMORA helped me find the perfect MBA program that fit my career goals. Their professional approach and personalized guidance made the entire process seamless.',
    },
    {
      image: '/testimonial-2.jpg',
      name: 'Rahul Nair',
      program: 'Career Counseling',
      detail: 'Healthcare Sector, India',
      rating: 5,
      quote: 'The career counseling sessions at ILMORA gave me clarity about my professional path. Their psychological assessment helped me understand my strengths better.',
    },
    {
      image: '/testimonial-3.jpg',
      name: 'Fatima Hassan',
      program: 'Psychology Support',
      detail: 'Personal Development, UAE',
      rating: 5,
      quote: 'The mental wellbeing support I received from ILMORA was transformative. They truly care about human-centered growth and long-term success.',
    },
  ];

  const nextTestimonial = () => {
    setActiveIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setActiveIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section
      ref={sectionRef}
      className="relative py-20 lg:py-32 bg-eduvista-light-bg overflow-hidden"
    >
      {/* Background Elements */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-eduvista-primary/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-eduvista-secondary/5 rounded-full blur-3xl" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div
            className={`inline-block px-4 py-1.5 rounded-full bg-eduvista-primary/20 mb-4 transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            <span className="text-eduvista-secondary text-sm font-semibold uppercase tracking-wider">
              Testimonials
            </span>
          </div>
          <h2
            className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-eduvista-secondary leading-tight transition-all duration-700 delay-100 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
          >
            What Our
            <span className="text-eduvista-primary"> Clients Say</span>
          </h2>
        </div>

        {/* Testimonials Carousel */}
        <div
          className={`relative max-w-4xl mx-auto transition-all duration-700 delay-200 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {/* Main Card */}
          <div className="relative bg-white rounded-3xl p-8 lg:p-12 shadow-xl">
            {/* Quote Icon */}
            <div className="absolute -top-6 left-8 p-4 rounded-2xl bg-eduvista-primary animate-float">
              <Quote className="w-6 h-6 text-eduvista-secondary" />
            </div>

            {/* Content */}
            <div className="pt-4">
              {testimonials.map((testimonial, index) => (
                <div
                  key={index}
                  className={`transition-all duration-500 ${
                    index === activeIndex
                      ? 'opacity-100 translate-x-0'
                      : 'opacity-0 absolute inset-0 translate-x-8 pointer-events-none'
                  }`}
                >
                  {/* Stars */}
                  <div className="flex gap-1 mb-6">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star
                        key={i}
                        className="w-5 h-5 fill-eduvista-primary text-eduvista-primary"
                      />
                    ))}
                  </div>

                  {/* Quote */}
                  <p className="text-xl lg:text-2xl text-eduvista-text-dark leading-relaxed mb-8 font-['Playfair_Display']">
                    "{testimonial.quote}"
                  </p>

                  {/* Author */}
                  <div className="flex items-center gap-4">
                    <img
                      src={testimonial.image}
                      alt={testimonial.name}
                      className="w-16 h-16 rounded-full object-cover border-4 border-eduvista-primary/20"
                    />
                    <div>
                      <div className="font-semibold text-eduvista-secondary text-lg">
                        {testimonial.name}
                      </div>
                      <div className="text-sm text-eduvista-text-gray">{testimonial.program}</div>
                      <div className="text-xs text-eduvista-primary">{testimonial.detail}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Navigation */}
            <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-100">
              {/* Dots */}
              <div className="flex gap-2">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setActiveIndex(index)}
                    className={`w-3 h-3 rounded-full transition-all duration-300 ${
                      index === activeIndex
                        ? 'bg-eduvista-primary w-8'
                        : 'bg-gray-300 hover:bg-gray-400'
                    }`}
                  />
                ))}
              </div>

              {/* Arrows */}
              <div className="flex gap-2">
                <button
                  onClick={prevTestimonial}
                  className="p-3 rounded-full bg-eduvista-light-bg hover:bg-eduvista-primary transition-colors duration-300 group"
                >
                  <ChevronLeft className="w-5 h-5 text-eduvista-secondary group-hover:text-eduvista-secondary" />
                </button>
                <button
                  onClick={nextTestimonial}
                  className="p-3 rounded-full bg-eduvista-light-bg hover:bg-eduvista-primary transition-colors duration-300 group"
                >
                  <ChevronRight className="w-5 h-5 text-eduvista-secondary group-hover:text-eduvista-secondary" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
