# EduVista Website - Editing Guide

## Quick Overview

Your website is built with **React + TypeScript + Tailwind CSS**. All the content is in the `/mnt/okcomputer/output/app/src/sections/` folder.

---

## Easy Edits (No Coding Experience Needed)

### 1. Change Company Name/Logo
**File:** `src/sections/Header.tsx` and `src/sections/Footer.tsx`

Look for:
```tsx
<span className="text-xl font-bold font-['Playfair_Display']">
  EduVista  {/* <-- Change this */}
</span>
```

### 2. Update Contact Information
**File:** `src/sections/Contact.tsx` (lines 40-47)

```tsx
const contactInfo = [
  { icon: Phone, label: 'Phone', value: '+91 98765 43210' },  {/* Change number */}
  { icon: Mail, label: 'Email', value: 'info@eduvista.com' },  {/* Change email */}
  { icon: MapPin, label: 'Address', value: '123 Education Street, Mumbai, India' },  {/* Change address */}
  { icon: Clock, label: 'Hours', value: 'Mon - Sat: 9AM - 6PM' },  {/* Change hours */}
];
```

Also update in **Footer.tsx** (around line 70-85).

### 3. Update Stats/Numbers
**File:** `src/sections/About.tsx` (lines 45-50)

```tsx
const targets = { years: 15, partners: 50, students: 15000, countries: 25 };
```

Also update in **Hero.tsx** (around lines 35-40).

### 4. Change Hero Headline/Text
**File:** `src/sections/Hero.tsx` (around lines 60-75)

```tsx
<h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
  <span>Unlock Your</span>
  <span>Potential With</span>
  <span className="text-eduvista-primary">Quality Education</span>  {/* Change text here */}
</h1>
```

### 5. Update Testimonials
**File:** `src/sections/Testimonials.tsx` (around lines 35-60)

```tsx
const testimonials = [
  {
    image: '/testimonial-1.jpg',
    name: 'Priya Sharma',  {/* Change name */}
    program: 'MBA Graduate',  {/* Change program */}
    detail: 'PG Program in Business Administration',  {/* Change detail */}
    rating: 5,
    quote: 'As a working professional...',  {/* Change quote */}
  },
  // ... more testimonials
];
```

### 6. Change Service Descriptions
**File:** `src/sections/Services.tsx` (around lines 75-95)

```tsx
const services = [
  {
    icon: GraduationCap,
    title: 'Flexible Degree Programs',  {/* Change title */}
    description: 'UG and PG programs...',  {/* Change description */}
    features: ['Online learning modules', 'Weekend classes', 'Industry-recognized degrees'],
  },
  // ... more services
];
```

---

## Medium Edits (Basic Understanding)

### 7. Change Colors
**File:** `src/index.css` (top of file)

```css
--eduvista-primary: #f9d806;    /* Yellow/Gold - Main accent */
--eduvista-secondary: #130f40;  /* Dark Navy - Backgrounds */
```

### 8. Add/Remove Navigation Links
**File:** `src/sections/Header.tsx` (around lines 15-25)

```tsx
const navLinks = [
  { name: 'Home', href: '#home' },
  { name: 'About', href: '#about' },
  { name: 'Services', href: '#services' },
  // Add or remove links here
];
```

### 9. Change Images
1. Add your new image to `/mnt/okcomputer/output/app/public/`
2. Update the reference in the section file:

**Example in Hero.tsx:**
```tsx
<img
  src="/your-new-image.jpg"  {/* Change this */}
  alt="Your description"
/>
```

**Current images used:**
- `/hero-student.jpg` - Hero section
- `/about-student.jpg` - About section
- `/working-professional.jpg` - Working Professionals section
- `/career-guidance.jpg` - Career Guidance section
- `/testimonial-1.jpg`, `/testimonial-2.jpg`, `/testimonial-3.jpg` - Testimonials

---

## Advanced Edits

### 10. Add a New Section

1. Create a new file in `src/sections/YourSection.tsx`
2. Copy structure from an existing section
3. Import and add to `src/App.tsx`:

```tsx
import YourSection from './sections/YourSection';

function App() {
  return (
    <div>
      <Header />
      <main>
        <Hero />
        {/* Add your section here */}
        <YourSection />
        <Footer />
      </main>
    </div>
  );
}
```

### 11. Modify Animations
Animations use CSS transitions and Intersection Observer. Look for:
- `transition-all duration-700` - Controls animation speed
- `opacity-0 translate-y-6` → `opacity-100 translate-y-0` - Fade up effect
- `delay-100`, `delay-200`, etc. - Stagger timing

---

## Rebuild and Redeploy After Changes

After making any edits, you need to rebuild:

```bash
cd /mnt/okcomputer/output/app
npm run build
```

Then redeploy:
```bash
# The dist folder will be updated automatically
# Just redeploy using the deploy tool
```

---

## File Structure Reference

```
/mnt/okcomputer/output/app/
├── src/
│   ├── sections/           # All page sections
│   │   ├── Header.tsx      # Navigation
│   │   ├── Hero.tsx        # Main banner
│   │   ├── About.tsx       # About us + stats
│   │   ├── Services.tsx    # Service cards
│   │   ├── WorkingProfessionals.tsx
│   │   ├── CareerGuidance.tsx
│   │   ├── AbroadAdmissions.tsx
│   │   ├── Testimonials.tsx
│   │   ├── Contact.tsx     # Form + contact info
│   │   └── Footer.tsx      # Footer
│   ├── App.tsx             # Main app (imports all sections)
│   ├── index.css           # Global styles + colors
│   └── main.tsx            # Entry point
├── public/                 # Images go here
│   ├── hero-student.jpg
│   ├── about-student.jpg
│   └── ...
└── dist/                   # Built files (auto-generated)
```

---

## Need Help?

If you want me to make specific changes, just tell me:
1. What you want to change
2. What the new content should be

I can edit the files for you and redeploy the website!
