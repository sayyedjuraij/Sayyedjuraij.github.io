import { GraduationCap, Facebook, Instagram, Linkedin, Twitter, ArrowUp } from 'lucide-react';

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const quickLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About Us', href: '#about' },
    { name: 'Services', href: '#services' },
    { name: 'Programs', href: '#programs' },
    { name: 'Contact', href: '#contact' },
  ];

  const services = [
    'Education Counseling',
    'Career Planning',
    'Psychology Support',
    'Healthcare Education',
    'Institutional Training',
  ];

  const socialLinks = [
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Linkedin, href: '#', label: 'LinkedIn' },
    { icon: Twitter, href: '#', label: 'Twitter' },
  ];

  return (
    <footer className="relative bg-eduvista-secondary overflow-hidden">
      {/* Top Wave */}
      <div className="absolute top-0 left-0 right-0 transform rotate-180">
        <svg viewBox="0 0 1440 60" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M0 60L60 55C120 50 240 40 360 35C480 30 600 30 720 32.5C840 35 960 40 1080 42.5C1200 45 1320 45 1380 45L1440 45V60H1380C1320 60 1200 60 1080 60C960 60 840 60 720 60C600 60 480 60 360 60C240 60 120 60 60 60H0Z"
            fill="white"
          />
        </svg>
      </div>

      {/* Gradient Line */}
      <div className="h-1 bg-gradient-to-r from-eduvista-primary via-purple-500 to-eduvista-primary" />

      <div className="relative z-10 pt-20 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
            {/* Company Info */}
            <div className="lg:col-span-1">
              <a href="#home" className="flex items-center gap-2 mb-6">
                <div className="p-2 rounded-xl bg-eduvista-primary">
                  <GraduationCap className="w-6 h-6 text-eduvista-secondary" />
                </div>
                <span className="text-lg font-bold text-white font-['Playfair_Display']">
                  ILMORA
                </span>
              </a>
              <p className="text-white/60 text-sm leading-relaxed mb-6">
                A knowledge-driven organization dedicated to education, psychological wellbeing, 
                and professional skill development. Building future-ready institutions through 
                ethical practices and learner-focused systems.
              </p>
              {/* Social Links */}
              <div className="flex gap-3">
                {socialLinks.map((social, index) => (
                  <a
                    key={index}
                    href={social.href}
                    aria-label={social.label}
                    className="p-2.5 rounded-full bg-white/10 hover:bg-eduvista-primary transition-all duration-300 group"
                  >
                    <social.icon className="w-4 h-4 text-white/60 group-hover:text-eduvista-secondary transition-colors duration-300" />
                  </a>
                ))}
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-white font-semibold mb-6">Quick Links</h4>
              <ul className="space-y-3">
                {quickLinks.map((link, index) => (
                  <li key={index}>
                    <a
                      href={link.href}
                      className="text-white/60 hover:text-eduvista-primary transition-colors duration-300 text-sm flex items-center gap-2 group"
                    >
                      <span className="w-0 h-0.5 bg-eduvista-primary transition-all duration-300 group-hover:w-3" />
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Services */}
            <div>
              <h4 className="text-white font-semibold mb-6">Our Services</h4>
              <ul className="space-y-3">
                {services.map((service, index) => (
                  <li key={index}>
                    <span className="text-white/60 text-sm flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-eduvista-primary" />
                      {service}
                    </span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="text-white font-semibold mb-6">Contact Us</h4>
              <div className="space-y-4">
                <div>
                  <div className="text-white/40 text-xs mb-1">UAE</div>
                  <div className="text-white/80 text-sm">+971 52 968 2123</div>
                </div>
                <div>
                  <div className="text-white/40 text-xs mb-1">India</div>
                  <div className="text-white/80 text-sm">+91 97449 80875</div>
                </div>
                <div>
                  <div className="text-white/40 text-xs mb-1">Operating Regions</div>
                  <div className="text-white/80 text-sm">
                    United Arab Emirates<br />
                    India
                  </div>
                </div>
                <div>
                  <div className="text-white/40 text-xs mb-1">Hours</div>
                  <div className="text-white/80 text-sm">Mon - Sat: 9AM - 6PM</div>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-white/40 text-sm">
              © 2024 ILMORA Education Group. All rights reserved.
            </p>
            <div className="flex items-center gap-6">
              <a href="#" className="text-white/40 hover:text-white text-sm transition-colors duration-300">
                Privacy Policy
              </a>
              <a href="#" className="text-white/40 hover:text-white text-sm transition-colors duration-300">
                Terms of Service
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll to Top Button */}
      <button
        onClick={scrollToTop}
        className="fixed bottom-8 right-8 p-4 rounded-full bg-eduvista-primary text-eduvista-secondary shadow-lg hover:shadow-xl hover:scale-110 transition-all duration-300 z-50"
        aria-label="Scroll to top"
      >
        <ArrowUp className="w-5 h-5" />
      </button>
    </footer>
  );
};

export default Footer;
